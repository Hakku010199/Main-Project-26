# Propaganda Detection Module

DistilBERT-based propaganda classification system.

## Setup
pip install -r requirements.txt

## Train
python src/training/train.py

## Predict
python src/training/predict.py
