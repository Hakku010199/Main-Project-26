label_map = {
    "pants-fire": 0,
    "false": 1,
    "barely-true": 2,
    "half-true": 3,
    "mostly-true": 4,
    "true": 5
}

label_names = [
    "Pants on Fire",
    "False",
    "Barely True",
    "Half True",
    "Mostly True",
    "True"
]
